<?php

namespace WGMSRM\Traits;

use WGMSRM\Classes\Migration;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Trait InitActions: Init action hooks defined here
 */
trait AdminInitActions {

	public function do_admin_init_actions() {
	}
}
